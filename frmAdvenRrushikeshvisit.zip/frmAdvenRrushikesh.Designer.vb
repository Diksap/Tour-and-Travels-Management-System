﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdvenRrushikesh
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdvenRrushikesh))
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.cbtnold = New System.Windows.Forms.CheckBox
        Me.cbtnadults = New System.Windows.Forms.CheckBox
        Me.cbtnchild = New System.Windows.Forms.CheckBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtnoofold = New System.Windows.Forms.TextBox
        Me.txtnoofadults = New System.Windows.Forms.TextBox
        Me.txtnoofchild = New System.Windows.Forms.TextBox
        Me.btntotal = New System.Windows.Forms.Button
        Me.txttot = New System.Windows.Forms.TextBox
        Me.lblbookingid = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.lbldays = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.btncancel = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rbtnVeg = New System.Windows.Forms.RadioButton
        Me.rbtnnonveg = New System.Windows.Forms.RadioButton
        Me.Label9 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rbtnac = New System.Windows.Forms.RadioButton
        Me.rbtnnonac = New System.Windows.Forms.RadioButton
        Me.btnconfirmbooking = New System.Windows.Forms.Button
        Me.lblplacename = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.btnpayment = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.Travelling = New System.Windows.Forms.GroupBox
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.rbtnTrain = New System.Windows.Forms.RadioButton
        Me.rbtnflight = New System.Windows.Forms.RadioButton
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblplaces = New System.Windows.Forms.Label
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Travelling.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.cbtnold)
        Me.GroupBox3.Controls.Add(Me.cbtnadults)
        Me.GroupBox3.Controls.Add(Me.cbtnchild)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.txtnoofold)
        Me.GroupBox3.Controls.Add(Me.txtnoofadults)
        Me.GroupBox3.Controls.Add(Me.txtnoofchild)
        Me.GroupBox3.Controls.Add(Me.btntotal)
        Me.GroupBox3.Controls.Add(Me.txttot)
        Me.GroupBox3.Controls.Add(Me.lblbookingid)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.lbldays)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.btncancel)
        Me.GroupBox3.Controls.Add(Me.GroupBox2)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.GroupBox1)
        Me.GroupBox3.Controls.Add(Me.btnconfirmbooking)
        Me.GroupBox3.Controls.Add(Me.lblplacename)
        Me.GroupBox3.Controls.Add(Me.PictureBox1)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.btnpayment)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.DateTimePicker2)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox3.Controls.Add(Me.Travelling)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.lblplaces)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1002, 698)
        Me.GroupBox3.TabIndex = 41
        Me.GroupBox3.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(153, 131)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(82, 13)
        Me.Label11.TabIndex = 60
        Me.Label11.Text = "5 Nights 6 Days"
        '
        'cbtnold
        '
        Me.cbtnold.AutoSize = True
        Me.cbtnold.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbtnold.Location = New System.Drawing.Point(49, 591)
        Me.cbtnold.Name = "cbtnold"
        Me.cbtnold.Size = New System.Drawing.Size(51, 20)
        Me.cbtnold.TabIndex = 59
        Me.cbtnold.Text = "Old"
        Me.cbtnold.UseVisualStyleBackColor = True
        '
        'cbtnadults
        '
        Me.cbtnadults.AutoSize = True
        Me.cbtnadults.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbtnadults.Location = New System.Drawing.Point(47, 565)
        Me.cbtnadults.Name = "cbtnadults"
        Me.cbtnadults.Size = New System.Drawing.Size(62, 20)
        Me.cbtnadults.TabIndex = 58
        Me.cbtnadults.Text = "Adult"
        Me.cbtnadults.UseVisualStyleBackColor = True
        '
        'cbtnchild
        '
        Me.cbtnchild.AutoSize = True
        Me.cbtnchild.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbtnchild.Location = New System.Drawing.Point(47, 539)
        Me.cbtnchild.Name = "cbtnchild"
        Me.cbtnchild.Size = New System.Drawing.Size(62, 20)
        Me.cbtnchild.TabIndex = 57
        Me.cbtnchild.Text = "Child"
        Me.cbtnchild.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(283, 591)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(65, 16)
        Me.Label20.TabIndex = 56
        Me.Label20.Text = "5000   rs"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(282, 565)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(65, 16)
        Me.Label18.TabIndex = 55
        Me.Label18.Text = "10000 rs"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(283, 539)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 16)
        Me.Label17.TabIndex = 54
        Me.Label17.Text = "7000   rs"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(369, 592)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(153, 16)
        Me.Label16.TabIndex = 53
        Me.Label16.Text = "Age Limit = Above 60"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(369, 566)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(219, 16)
        Me.Label15.TabIndex = 52
        Me.Label15.Text = "Age Limit  = 18 year to 60 year "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(369, 539)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(207, 16)
        Me.Label14.TabIndex = 51
        Me.Label14.Text = "Age Limit = 1 year  to 18 year"
        '
        'txtnoofold
        '
        Me.txtnoofold.Location = New System.Drawing.Point(149, 591)
        Me.txtnoofold.Name = "txtnoofold"
        Me.txtnoofold.Size = New System.Drawing.Size(127, 20)
        Me.txtnoofold.TabIndex = 50
        '
        'txtnoofadults
        '
        Me.txtnoofadults.Location = New System.Drawing.Point(149, 565)
        Me.txtnoofadults.Name = "txtnoofadults"
        Me.txtnoofadults.Size = New System.Drawing.Size(127, 20)
        Me.txtnoofadults.TabIndex = 49
        '
        'txtnoofchild
        '
        Me.txtnoofchild.Location = New System.Drawing.Point(149, 539)
        Me.txtnoofchild.Name = "txtnoofchild"
        Me.txtnoofchild.Size = New System.Drawing.Size(127, 20)
        Me.txtnoofchild.TabIndex = 48
        '
        'btntotal
        '
        Me.btntotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntotal.Location = New System.Drawing.Point(759, 331)
        Me.btntotal.Name = "btntotal"
        Me.btntotal.Size = New System.Drawing.Size(131, 40)
        Me.btntotal.TabIndex = 44
        Me.btntotal.Text = "Total"
        Me.btntotal.UseVisualStyleBackColor = True
        '
        'txttot
        '
        Me.txttot.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttot.Location = New System.Drawing.Point(151, 623)
        Me.txttot.Name = "txttot"
        Me.txttot.Size = New System.Drawing.Size(127, 38)
        Me.txttot.TabIndex = 43
        '
        'lblbookingid
        '
        Me.lblbookingid.AutoSize = True
        Me.lblbookingid.Location = New System.Drawing.Point(153, 62)
        Me.lblbookingid.Name = "lblbookingid"
        Me.lblbookingid.Size = New System.Drawing.Size(45, 13)
        Me.lblbookingid.TabIndex = 42
        Me.lblbookingid.Text = "Label11"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(44, 59)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(90, 16)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "Booking Id :"
        '
        'lbldays
        '
        Me.lbldays.AutoSize = True
        Me.lbldays.Location = New System.Drawing.Point(153, 121)
        Me.lbldays.Name = "lbldays"
        Me.lbldays.Size = New System.Drawing.Size(0, 13)
        Me.lbldays.TabIndex = 38
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(44, 126)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(52, 16)
        Me.Label19.TabIndex = 37
        Me.Label19.Text = "Days :"
        '
        'btncancel
        '
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(759, 527)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(131, 40)
        Me.btncancel.TabIndex = 34
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbtnVeg)
        Me.GroupBox2.Controls.Add(Me.rbtnnonveg)
        Me.GroupBox2.Location = New System.Drawing.Point(150, 295)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(129, 62)
        Me.GroupBox2.TabIndex = 33
        Me.GroupBox2.TabStop = False
        '
        'rbtnVeg
        '
        Me.rbtnVeg.AutoSize = True
        Me.rbtnVeg.Location = New System.Drawing.Point(4, 14)
        Me.rbtnVeg.Name = "rbtnVeg"
        Me.rbtnVeg.Size = New System.Drawing.Size(113, 17)
        Me.rbtnVeg.TabIndex = 17
        Me.rbtnVeg.TabStop = True
        Me.rbtnVeg.Text = "VEG              2000"
        Me.rbtnVeg.UseVisualStyleBackColor = True
        '
        'rbtnnonveg
        '
        Me.rbtnnonveg.AutoSize = True
        Me.rbtnnonveg.Location = New System.Drawing.Point(6, 37)
        Me.rbtnnonveg.Name = "rbtnnonveg"
        Me.rbtnnonveg.Size = New System.Drawing.Size(113, 17)
        Me.rbtnnonveg.TabIndex = 18
        Me.rbtnnonveg.TabStop = True
        Me.rbtnnonveg.Text = "NON-VEG     3500"
        Me.rbtnnonveg.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Bookman Old Style", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(379, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(198, 41)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Rishikesh"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbtnac)
        Me.GroupBox1.Controls.Add(Me.rbtnnonac)
        Me.GroupBox1.Location = New System.Drawing.Point(149, 229)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(118, 60)
        Me.GroupBox1.TabIndex = 32
        Me.GroupBox1.TabStop = False
        '
        'rbtnac
        '
        Me.rbtnac.AutoSize = True
        Me.rbtnac.Location = New System.Drawing.Point(6, 8)
        Me.rbtnac.Name = "rbtnac"
        Me.rbtnac.Size = New System.Drawing.Size(98, 17)
        Me.rbtnac.TabIndex = 29
        Me.rbtnac.TabStop = True
        Me.rbtnac.Text = " A/C         8000"
        Me.rbtnac.UseVisualStyleBackColor = True
        '
        'rbtnnonac
        '
        Me.rbtnnonac.AutoSize = True
        Me.rbtnnonac.Location = New System.Drawing.Point(6, 31)
        Me.rbtnnonac.Name = "rbtnnonac"
        Me.rbtnnonac.Size = New System.Drawing.Size(100, 17)
        Me.rbtnnonac.TabIndex = 28
        Me.rbtnnonac.TabStop = True
        Me.rbtnnonac.Text = "Non A/C   5000"
        Me.rbtnnonac.UseVisualStyleBackColor = True
        '
        'btnconfirmbooking
        '
        Me.btnconfirmbooking.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirmbooking.Location = New System.Drawing.Point(759, 388)
        Me.btnconfirmbooking.Name = "btnconfirmbooking"
        Me.btnconfirmbooking.Size = New System.Drawing.Size(131, 59)
        Me.btnconfirmbooking.TabIndex = 26
        Me.btnconfirmbooking.Text = "Confirm Booking"
        Me.btnconfirmbooking.UseVisualStyleBackColor = True
        '
        'lblplacename
        '
        Me.lblplacename.AutoSize = True
        Me.lblplacename.Location = New System.Drawing.Point(148, 101)
        Me.lblplacename.Name = "lblplacename"
        Me.lblplacename.Size = New System.Drawing.Size(80, 13)
        Me.lblplacename.TabIndex = 23
        Me.lblplacename.Text = "Delhi-Rishikesh"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(674, 19)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(295, 209)
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(151, 160)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(360, 52)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = resources.GetString("Label8.Text")
        '
        'btnpayment
        '
        Me.btnpayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpayment.Location = New System.Drawing.Point(759, 464)
        Me.btnpayment.Name = "btnpayment"
        Me.btnpayment.Size = New System.Drawing.Size(131, 40)
        Me.btnpayment.TabIndex = 16
        Me.btnpayment.Text = "Payment"
        Me.btnpayment.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(45, 623)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(89, 31)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Total:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(44, 237)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 16)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Hotel Type: "
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(149, 501)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(177, 20)
        Me.DateTimePicker2.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(44, 501)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 16)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "To Date:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(44, 464)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "From Date:"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(149, 464)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(177, 20)
        Me.DateTimePicker1.TabIndex = 5
        '
        'Travelling
        '
        Me.Travelling.Controls.Add(Me.RadioButton1)
        Me.Travelling.Controls.Add(Me.rbtnTrain)
        Me.Travelling.Controls.Add(Me.rbtnflight)
        Me.Travelling.Location = New System.Drawing.Point(149, 363)
        Me.Travelling.Name = "Travelling"
        Me.Travelling.Size = New System.Drawing.Size(164, 84)
        Me.Travelling.TabIndex = 4
        Me.Travelling.TabStop = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(13, 15)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(103, 17)
        Me.RadioButton1.TabIndex = 2
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Bus            1600"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'rbtnTrain
        '
        Me.rbtnTrain.AutoSize = True
        Me.rbtnTrain.Location = New System.Drawing.Point(12, 38)
        Me.rbtnTrain.Name = "rbtnTrain"
        Me.rbtnTrain.Size = New System.Drawing.Size(106, 17)
        Me.rbtnTrain.TabIndex = 0
        Me.rbtnTrain.TabStop = True
        Me.rbtnTrain.Text = "Train           3700"
        Me.rbtnTrain.UseVisualStyleBackColor = True
        '
        'rbtnflight
        '
        Me.rbtnflight.AutoSize = True
        Me.rbtnflight.Location = New System.Drawing.Point(12, 61)
        Me.rbtnflight.Name = "rbtnflight"
        Me.rbtnflight.Size = New System.Drawing.Size(107, 17)
        Me.rbtnflight.TabIndex = 1
        Me.rbtnflight.TabStop = True
        Me.rbtnflight.Text = "Flight           5000"
        Me.rbtnflight.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(44, 388)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 16)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Travelling:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(44, 158)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Destinations:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(44, 310)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Food:"
        '
        'lblplaces
        '
        Me.lblplaces.AutoSize = True
        Me.lblplaces.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblplaces.Location = New System.Drawing.Point(44, 97)
        Me.lblplaces.Name = "lblplaces"
        Me.lblplaces.Size = New System.Drawing.Size(97, 16)
        Me.lblplaces.TabIndex = 0
        Me.lblplaces.Text = "Place Name:"
        '
        'frmAdvenRrushikesh
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1240, 712)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "frmAdvenRrushikesh"
        Me.Text = "frmAdven"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Travelling.ResumeLayout(False)
        Me.Travelling.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cbtnold As System.Windows.Forms.CheckBox
    Friend WithEvents cbtnadults As System.Windows.Forms.CheckBox
    Friend WithEvents cbtnchild As System.Windows.Forms.CheckBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtnoofold As System.Windows.Forms.TextBox
    Friend WithEvents txtnoofadults As System.Windows.Forms.TextBox
    Friend WithEvents txtnoofchild As System.Windows.Forms.TextBox
    Friend WithEvents btntotal As System.Windows.Forms.Button
    Friend WithEvents txttot As System.Windows.Forms.TextBox
    Friend WithEvents lblbookingid As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lbldays As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnVeg As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnnonveg As System.Windows.Forms.RadioButton
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnac As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnnonac As System.Windows.Forms.RadioButton
    Friend WithEvents btnconfirmbooking As System.Windows.Forms.Button
    Friend WithEvents lblplacename As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnpayment As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Travelling As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnTrain As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnflight As System.Windows.Forms.RadioButton
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblplaces As System.Windows.Forms.Label
End Class
