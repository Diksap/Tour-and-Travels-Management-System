﻿Imports System.Data.OleDb
Public Class frmadminpaymentd
    Dim con As New OleDbConnection
    Dim i As Integer
    Dim cmd As New OleDbCommand
    Dim da As New OleDbDataAdapter
    Dim ds As New DataSet
    Dim dt As New DataTable
    Private Sub frmadminpaymentd_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Tours_and_Travels_Management_SystemDataSet2.Payment' table. You can move, or remove it, as needed.
        'Me.PaymentTableAdapter.Fill(Me.Tours_and_Travels_Management_SystemDataSet2.Payment)
        'TODO: This line of code loads data into the 'Tours_and_Travels_Management_System_FinalDataSet.Payment' table. You can move, or remove it, as needed.

        
    End Sub

    

    Private Sub btncancelpay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancelpay.Click
        Me.Close()
    End Sub

    Private Sub btnsearchpay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsearchpay.Click
        

        con = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\VB.NET Project Sem 6\Tours and Travels Management System.mdb")
        con.Open()
        ds.Tables.Add(dt)
        da = New OleDbDataAdapter("Select * from Payment", con)
        da.Fill(ds)
        paymentDataGridView1.DataSource = ds.Tables(0)
        ' da = New OleDbDataAdapter("select *from Payment ", con)
        'da.Fill(dt)
        'paymentDataGridView1.DataSource = dt.DefaultView
        con.Close()
    End Sub
End Class