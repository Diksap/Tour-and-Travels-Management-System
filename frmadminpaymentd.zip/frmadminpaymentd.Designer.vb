﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmadminpaymentd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmadminpaymentd))
        Me.Label8 = New System.Windows.Forms.Label
        Me.btncancelpay = New System.Windows.Forms.Button
        Me.paymentDataGridView1 = New System.Windows.Forms.DataGridView
        Me.Tours_and_Travels_Management_SystemDataSet2 = New WindowsApplication1.Tours_and_Travels_Management_SystemDataSet2
        Me.PaymentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PaymentTableAdapter = New WindowsApplication1.Tours_and_Travels_Management_SystemDataSet2TableAdapters.PaymentTableAdapter
        Me.CidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ContactNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.AdharNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EmailIdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.BookingidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PlaceNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DaysDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.HotelNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.HotelTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.FoodDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TravellingModeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.FromDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ToDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NoofChildDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NoofAdultDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NoofOldDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TotalDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btnsearchpay = New System.Windows.Forms.Button
        CType(Me.paymentDataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Tours_and_Travels_Management_SystemDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PaymentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Bookman Old Style", 27.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(525, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(339, 43)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "Payment Details"
        '
        'btncancelpay
        '
        Me.btncancelpay.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancelpay.Location = New System.Drawing.Point(673, 109)
        Me.btncancelpay.Name = "btncancelpay"
        Me.btncancelpay.Size = New System.Drawing.Size(114, 43)
        Me.btncancelpay.TabIndex = 41
        Me.btncancelpay.Text = "Cancel"
        Me.btncancelpay.UseVisualStyleBackColor = True
        '
        'paymentDataGridView1
        '
        Me.paymentDataGridView1.AutoGenerateColumns = False
        Me.paymentDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.paymentDataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CidDataGridViewTextBoxColumn, Me.NameDataGridViewTextBoxColumn, Me.ContactNoDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.AdharNoDataGridViewTextBoxColumn, Me.EmailIdDataGridViewTextBoxColumn, Me.BookingidDataGridViewTextBoxColumn, Me.PlaceNameDataGridViewTextBoxColumn, Me.DaysDataGridViewTextBoxColumn, Me.HotelNameDataGridViewTextBoxColumn, Me.HotelTypeDataGridViewTextBoxColumn, Me.FoodDataGridViewTextBoxColumn, Me.TravellingModeDataGridViewTextBoxColumn, Me.FromDateDataGridViewTextBoxColumn, Me.ToDateDataGridViewTextBoxColumn, Me.NoofChildDataGridViewTextBoxColumn, Me.NoofAdultDataGridViewTextBoxColumn, Me.NoofOldDataGridViewTextBoxColumn, Me.TotalDataGridViewTextBoxColumn})
        Me.paymentDataGridView1.DataSource = Me.PaymentBindingSource
        Me.paymentDataGridView1.Location = New System.Drawing.Point(264, 200)
        Me.paymentDataGridView1.Name = "paymentDataGridView1"
        Me.paymentDataGridView1.Size = New System.Drawing.Size(942, 264)
        Me.paymentDataGridView1.TabIndex = 42
        '
        'Tours_and_Travels_Management_SystemDataSet2
        '
        Me.Tours_and_Travels_Management_SystemDataSet2.DataSetName = "Tours_and_Travels_Management_SystemDataSet2"
        Me.Tours_and_Travels_Management_SystemDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PaymentBindingSource
        '
        Me.PaymentBindingSource.DataMember = "Payment"
        Me.PaymentBindingSource.DataSource = Me.Tours_and_Travels_Management_SystemDataSet2
        '
        'PaymentTableAdapter
        '
        Me.PaymentTableAdapter.ClearBeforeFill = True
        '
        'CidDataGridViewTextBoxColumn
        '
        Me.CidDataGridViewTextBoxColumn.DataPropertyName = "C_id"
        Me.CidDataGridViewTextBoxColumn.HeaderText = "C_id"
        Me.CidDataGridViewTextBoxColumn.Name = "CidDataGridViewTextBoxColumn"
        '
        'NameDataGridViewTextBoxColumn
        '
        Me.NameDataGridViewTextBoxColumn.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn.Name = "NameDataGridViewTextBoxColumn"
        '
        'ContactNoDataGridViewTextBoxColumn
        '
        Me.ContactNoDataGridViewTextBoxColumn.DataPropertyName = "Contact_No"
        Me.ContactNoDataGridViewTextBoxColumn.HeaderText = "Contact_No"
        Me.ContactNoDataGridViewTextBoxColumn.Name = "ContactNoDataGridViewTextBoxColumn"
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        '
        'AdharNoDataGridViewTextBoxColumn
        '
        Me.AdharNoDataGridViewTextBoxColumn.DataPropertyName = "AdharNo"
        Me.AdharNoDataGridViewTextBoxColumn.HeaderText = "AdharNo"
        Me.AdharNoDataGridViewTextBoxColumn.Name = "AdharNoDataGridViewTextBoxColumn"
        '
        'EmailIdDataGridViewTextBoxColumn
        '
        Me.EmailIdDataGridViewTextBoxColumn.DataPropertyName = "Email-Id"
        Me.EmailIdDataGridViewTextBoxColumn.HeaderText = "Email-Id"
        Me.EmailIdDataGridViewTextBoxColumn.Name = "EmailIdDataGridViewTextBoxColumn"
        '
        'BookingidDataGridViewTextBoxColumn
        '
        Me.BookingidDataGridViewTextBoxColumn.DataPropertyName = "Booking_id"
        Me.BookingidDataGridViewTextBoxColumn.HeaderText = "Booking_id"
        Me.BookingidDataGridViewTextBoxColumn.Name = "BookingidDataGridViewTextBoxColumn"
        '
        'PlaceNameDataGridViewTextBoxColumn
        '
        Me.PlaceNameDataGridViewTextBoxColumn.DataPropertyName = "PlaceName"
        Me.PlaceNameDataGridViewTextBoxColumn.HeaderText = "PlaceName"
        Me.PlaceNameDataGridViewTextBoxColumn.Name = "PlaceNameDataGridViewTextBoxColumn"
        '
        'DaysDataGridViewTextBoxColumn
        '
        Me.DaysDataGridViewTextBoxColumn.DataPropertyName = "Days"
        Me.DaysDataGridViewTextBoxColumn.HeaderText = "Days"
        Me.DaysDataGridViewTextBoxColumn.Name = "DaysDataGridViewTextBoxColumn"
        '
        'HotelNameDataGridViewTextBoxColumn
        '
        Me.HotelNameDataGridViewTextBoxColumn.DataPropertyName = "HotelName"
        Me.HotelNameDataGridViewTextBoxColumn.HeaderText = "HotelName"
        Me.HotelNameDataGridViewTextBoxColumn.Name = "HotelNameDataGridViewTextBoxColumn"
        '
        'HotelTypeDataGridViewTextBoxColumn
        '
        Me.HotelTypeDataGridViewTextBoxColumn.DataPropertyName = "HotelType"
        Me.HotelTypeDataGridViewTextBoxColumn.HeaderText = "HotelType"
        Me.HotelTypeDataGridViewTextBoxColumn.Name = "HotelTypeDataGridViewTextBoxColumn"
        '
        'FoodDataGridViewTextBoxColumn
        '
        Me.FoodDataGridViewTextBoxColumn.DataPropertyName = "Food"
        Me.FoodDataGridViewTextBoxColumn.HeaderText = "Food"
        Me.FoodDataGridViewTextBoxColumn.Name = "FoodDataGridViewTextBoxColumn"
        '
        'TravellingModeDataGridViewTextBoxColumn
        '
        Me.TravellingModeDataGridViewTextBoxColumn.DataPropertyName = "TravellingMode"
        Me.TravellingModeDataGridViewTextBoxColumn.HeaderText = "TravellingMode"
        Me.TravellingModeDataGridViewTextBoxColumn.Name = "TravellingModeDataGridViewTextBoxColumn"
        '
        'FromDateDataGridViewTextBoxColumn
        '
        Me.FromDateDataGridViewTextBoxColumn.DataPropertyName = "FromDate"
        Me.FromDateDataGridViewTextBoxColumn.HeaderText = "FromDate"
        Me.FromDateDataGridViewTextBoxColumn.Name = "FromDateDataGridViewTextBoxColumn"
        '
        'ToDateDataGridViewTextBoxColumn
        '
        Me.ToDateDataGridViewTextBoxColumn.DataPropertyName = "ToDate"
        Me.ToDateDataGridViewTextBoxColumn.HeaderText = "ToDate"
        Me.ToDateDataGridViewTextBoxColumn.Name = "ToDateDataGridViewTextBoxColumn"
        '
        'NoofChildDataGridViewTextBoxColumn
        '
        Me.NoofChildDataGridViewTextBoxColumn.DataPropertyName = "NoofChild"
        Me.NoofChildDataGridViewTextBoxColumn.HeaderText = "NoofChild"
        Me.NoofChildDataGridViewTextBoxColumn.Name = "NoofChildDataGridViewTextBoxColumn"
        '
        'NoofAdultDataGridViewTextBoxColumn
        '
        Me.NoofAdultDataGridViewTextBoxColumn.DataPropertyName = "NoofAdult"
        Me.NoofAdultDataGridViewTextBoxColumn.HeaderText = "NoofAdult"
        Me.NoofAdultDataGridViewTextBoxColumn.Name = "NoofAdultDataGridViewTextBoxColumn"
        '
        'NoofOldDataGridViewTextBoxColumn
        '
        Me.NoofOldDataGridViewTextBoxColumn.DataPropertyName = "NoofOld"
        Me.NoofOldDataGridViewTextBoxColumn.HeaderText = "NoofOld"
        Me.NoofOldDataGridViewTextBoxColumn.Name = "NoofOldDataGridViewTextBoxColumn"
        '
        'TotalDataGridViewTextBoxColumn
        '
        Me.TotalDataGridViewTextBoxColumn.DataPropertyName = "Total"
        Me.TotalDataGridViewTextBoxColumn.HeaderText = "Total"
        Me.TotalDataGridViewTextBoxColumn.Name = "TotalDataGridViewTextBoxColumn"
        '
        'btnsearchpay
        '
        Me.btnsearchpay.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsearchpay.Location = New System.Drawing.Point(425, 104)
        Me.btnsearchpay.Name = "btnsearchpay"
        Me.btnsearchpay.Size = New System.Drawing.Size(180, 48)
        Me.btnsearchpay.TabIndex = 43
        Me.btnsearchpay.Text = "Payment Details"
        Me.btnsearchpay.UseVisualStyleBackColor = True
        '
        'frmadminpaymentd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.btnsearchpay)
        Me.Controls.Add(Me.paymentDataGridView1)
        Me.Controls.Add(Me.btncancelpay)
        Me.Controls.Add(Me.Label8)
        Me.Name = "frmadminpaymentd"
        Me.Text = "frmadminpaymentd"
        CType(Me.paymentDataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Tours_and_Travels_Management_SystemDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PaymentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btncancelpay As System.Windows.Forms.Button
    Friend WithEvents paymentDataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Tours_and_Travels_Management_SystemDataSet2 As WindowsApplication1.Tours_and_Travels_Management_SystemDataSet2
    Friend WithEvents PaymentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PaymentTableAdapter As WindowsApplication1.Tours_and_Travels_Management_SystemDataSet2TableAdapters.PaymentTableAdapter
    Friend WithEvents CidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContactNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AdharNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EmailIdDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BookingidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PlaceNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DaysDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HotelNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HotelTypeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FoodDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TravellingModeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FromDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ToDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NoofChildDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NoofAdultDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NoofOldDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnsearchpay As System.Windows.Forms.Button
End Class
