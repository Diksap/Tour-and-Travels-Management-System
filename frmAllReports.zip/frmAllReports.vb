﻿Imports System.Data.OleDb
Public Class frmAllReports

    Private Sub btnconfirmbooking_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles f.Click
        Dim myreport As New DemoReport
        CrystalReportViewer1.ReportSource = myreport
    End Sub
    
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

    End Sub
End Class