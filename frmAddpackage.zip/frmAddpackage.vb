﻿Imports System.Data.OleDb
Public Class frmAddpackage
    Dim con As New OleDbConnection
    Dim i As Integer
    Dim cmd As New OleDbCommand
    Dim da As New OleDbDataAdapter
    Dim ds As New DataSet
    Private Sub frmAddpackage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EmployeeDetailsDataSet.Employee' table. You can move, or remove it, as needed.
        'Me.PackagesAdapter.Fill(Me.PackagesDataSet.Employee)
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\VB.NET Project Sem 6\Tours and Travels Management System.mdb")
        con.Open()
        'MsgBox("Data Connection is created")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub btntotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnaddnew.Click
        Dim s As String
        s = "INSERT INTO Packages values('" & txtbid.Text & "','" & txtpacknm.Text & "','" & txtpacktype.Text & "','" & txtplacenm.Text & "','" & txtdays.Text & "','" & txtdesti.Text & "','" & txtbaschar.Text & "','" & txthotelnm.Text & "')"
        cmd = New OleDbCommand(s, con)
        cmd.ExecuteNonQuery()
        MsgBox("Your Record is Added")
        cmd.Dispose()
        con.Close()
    End Sub

    'Provider=Microsoft.Jet.OLEDB.4.0;Data Source="D:\VB.NET Project Sem 6\Tours and Travels Management System.mdb"
End Class