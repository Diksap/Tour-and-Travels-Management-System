﻿Imports System.Data.OleDb
Public Class frmEditpackage
    Dim con As New OleDbConnection
    Dim i As Integer
    Dim cmd As New OleDbCommand
    Dim dba As New OleDbDataAdapter
    Dim ds As New DataSet

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        'Dim s As String
        's = "Update Student set SClass=SYBCA where SClass='TYBCA'"
        'dba.UpdateCommand = con.CreateCommand
        'dba.UpdateCommand.CommandText = s
        'dba.UpdateCommand.ExecuteNonQuery()
        'MsgBox("Data is updated....")
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\VB.NET Project Sem 6\Tours and Travels Management System.mdb")
        con.Open()
        Dim s As String
        s = "Update Packages set [package_nm]='" & txtepnm.Text & "',[package_type]='" & txteptype.Text & "', [place_nm]='" & txteplacenm.Text & "', [days]='" & txtedays.Text & "', [destination]='" & txtedesti.Text & "',[basic_charge]='" & txtebaschar.Text & "',[hotel_nm]='" & txtehotelnm.Text & "'where [P_id]= & txtpid.Text & '"
        dba.UpdateCommand = con.CreateCommand
        dba.UpdateCommand.CommandText = s
        dba.UpdateCommand.ExecuteNonQuery()
        MsgBox("Data is updated....")

    End Sub
End Class