﻿Public Class frmemployeemenu


    Private Sub frmusermenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'to make label & buttons transparents
        Label1.BackColor = System.Drawing.Color.Transparent

        btncustomizepackage.FlatStyle = FlatStyle.Flat
        btncustomizepackage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        btncustomizepackage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        btncustomizepackage.BackColor = System.Drawing.Color.Transparent

        btngrouppackage.FlatStyle = FlatStyle.Flat
        btngrouppackage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        btngrouppackage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        btngrouppackage.BackColor = System.Drawing.Color.Transparent

        btnadventurepackage.FlatStyle = FlatStyle.Flat
        btnadventurepackage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        btnadventurepackage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        btnadventurepackage.BackColor = System.Drawing.Color.Transparent

        btnhoneymoonpackage.FlatStyle = FlatStyle.Flat
        btnhoneymoonpackage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        btnhoneymoonpackage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        btnhoneymoonpackage.BackColor = System.Drawing.Color.Transparent

        btnpayment.FlatStyle = FlatStyle.Flat
        btnpayment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        btnpayment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        btnpayment.BackColor = System.Drawing.Color.Transparent

        btncancellation.FlatStyle = FlatStyle.Flat
        btncancellation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        btncancellation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        btncancellation.BackColor = System.Drawing.Color.Transparent

        btnprintticket.FlatStyle = FlatStyle.Flat
        btnprintticket.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        btnprintticket.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        btnprintticket.BackColor = System.Drawing.Color.Transparent
    End Sub

    Private Sub btncustomizepackage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncustomizepackage.Click
        frmViewDetailscustomize.Show()
    End Sub

    Private Sub btnpayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpayment.Click
        frmPayment.Show()
    End Sub

    Private Sub btncancellation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancellation.Click
        frmcancellation.Show()
    End Sub

    Private Sub btnprintticket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprintticket.Click
        frmprintticket.Show()
    End Sub

    Private Sub btngrouppackage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngrouppackage.Click
        frmViewdetailsgroup.Show()
    End Sub

    Private Sub btnhoneymoonpackage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhoneymoonpackage.Click
        frmViewdetailsHM.Show()
    End Sub

    Private Sub btnadventurepackage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadventurepackage.Click
        frmViewdetailsadven.Show()
    End Sub
End Class