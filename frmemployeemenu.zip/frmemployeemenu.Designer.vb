﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmemployeemenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btncustomizepackage = New System.Windows.Forms.Button
        Me.btngrouppackage = New System.Windows.Forms.Button
        Me.btnadventurepackage = New System.Windows.Forms.Button
        Me.btnhoneymoonpackage = New System.Windows.Forms.Button
        Me.btncancellation = New System.Windows.Forms.Button
        Me.btnpayment = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnprintticket = New System.Windows.Forms.Button
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btncustomizepackage
        '
        Me.btncustomizepackage.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncustomizepackage.ForeColor = System.Drawing.Color.Red
        Me.btncustomizepackage.Location = New System.Drawing.Point(12, 125)
        Me.btncustomizepackage.Name = "btncustomizepackage"
        Me.btncustomizepackage.Size = New System.Drawing.Size(272, 70)
        Me.btncustomizepackage.TabIndex = 0
        Me.btncustomizepackage.Text = "Customize Package"
        Me.btncustomizepackage.UseVisualStyleBackColor = True
        '
        'btngrouppackage
        '
        Me.btngrouppackage.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngrouppackage.ForeColor = System.Drawing.Color.Red
        Me.btngrouppackage.Location = New System.Drawing.Point(12, 201)
        Me.btngrouppackage.Name = "btngrouppackage"
        Me.btngrouppackage.Size = New System.Drawing.Size(272, 70)
        Me.btngrouppackage.TabIndex = 1
        Me.btngrouppackage.Text = "Group Package"
        Me.btngrouppackage.UseVisualStyleBackColor = True
        '
        'btnadventurepackage
        '
        Me.btnadventurepackage.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadventurepackage.ForeColor = System.Drawing.Color.Red
        Me.btnadventurepackage.Location = New System.Drawing.Point(12, 277)
        Me.btnadventurepackage.Name = "btnadventurepackage"
        Me.btnadventurepackage.Size = New System.Drawing.Size(272, 70)
        Me.btnadventurepackage.TabIndex = 2
        Me.btnadventurepackage.Text = "Adventure Package"
        Me.btnadventurepackage.UseVisualStyleBackColor = True
        '
        'btnhoneymoonpackage
        '
        Me.btnhoneymoonpackage.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhoneymoonpackage.ForeColor = System.Drawing.Color.Red
        Me.btnhoneymoonpackage.Location = New System.Drawing.Point(12, 353)
        Me.btnhoneymoonpackage.Name = "btnhoneymoonpackage"
        Me.btnhoneymoonpackage.Size = New System.Drawing.Size(272, 70)
        Me.btnhoneymoonpackage.TabIndex = 3
        Me.btnhoneymoonpackage.Text = "Honeymoon Package"
        Me.btnhoneymoonpackage.UseVisualStyleBackColor = True
        '
        'btncancellation
        '
        Me.btncancellation.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancellation.ForeColor = System.Drawing.Color.Red
        Me.btncancellation.Location = New System.Drawing.Point(12, 505)
        Me.btncancellation.Name = "btncancellation"
        Me.btncancellation.Size = New System.Drawing.Size(272, 70)
        Me.btncancellation.TabIndex = 4
        Me.btncancellation.Text = "Cancellation"
        Me.btncancellation.UseVisualStyleBackColor = True
        '
        'btnpayment
        '
        Me.btnpayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpayment.ForeColor = System.Drawing.Color.Red
        Me.btnpayment.Location = New System.Drawing.Point(12, 429)
        Me.btnpayment.Name = "btnpayment"
        Me.btnpayment.Size = New System.Drawing.Size(272, 70)
        Me.btnpayment.TabIndex = 5
        Me.btnpayment.Text = "Payment"
        Me.btnpayment.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(362, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(919, 55)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Tours And Travels Management System"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Tours_and_Travels_Management_System.My.Resources.Resources.logo1
        Me.PictureBox1.Location = New System.Drawing.Point(182, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(152, 107)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnprintticket
        '
        Me.btnprintticket.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprintticket.ForeColor = System.Drawing.Color.Red
        Me.btnprintticket.Location = New System.Drawing.Point(12, 581)
        Me.btnprintticket.Name = "btnprintticket"
        Me.btnprintticket.Size = New System.Drawing.Size(272, 70)
        Me.btnprintticket.TabIndex = 6
        Me.btnprintticket.Text = "Print Ticket"
        Me.btnprintticket.UseVisualStyleBackColor = True
        '
        'frmemployeemenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Tours_and_Travels_Management_System.My.Resources.Resources.usermenu6
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.btnprintticket)
        Me.Controls.Add(Me.btncancellation)
        Me.Controls.Add(Me.btngrouppackage)
        Me.Controls.Add(Me.btnpayment)
        Me.Controls.Add(Me.btncustomizepackage)
        Me.Controls.Add(Me.btnhoneymoonpackage)
        Me.Controls.Add(Me.btnadventurepackage)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.DoubleBuffered = True
        Me.Name = "frmemployeemenu"
        Me.Text = "frmusermenu"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btncustomizepackage As System.Windows.Forms.Button
    Friend WithEvents btngrouppackage As System.Windows.Forms.Button
    Friend WithEvents btnadventurepackage As System.Windows.Forms.Button
    Friend WithEvents btnhoneymoonpackage As System.Windows.Forms.Button
    Friend WithEvents btncancellation As System.Windows.Forms.Button
    Friend WithEvents btnpayment As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnprintticket As System.Windows.Forms.Button
End Class
