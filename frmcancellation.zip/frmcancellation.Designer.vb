﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmcancellation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtmobno = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblcancellationid = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.txtemailid = New System.Windows.Forms.TextBox
        Me.txtadharcardno = New System.Windows.Forms.TextBox
        Me.txtaddress = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.lblcid = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtname = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txttotal = New System.Windows.Forms.TextBox
        Me.txtnoofold = New System.Windows.Forms.TextBox
        Me.txtnoofadult = New System.Windows.Forms.TextBox
        Me.txtnoofchild = New System.Windows.Forms.TextBox
        Me.txttodate = New System.Windows.Forms.TextBox
        Me.txtfromdate = New System.Windows.Forms.TextBox
        Me.txttravellingmode = New System.Windows.Forms.TextBox
        Me.txtfood = New System.Windows.Forms.TextBox
        Me.txthoteltype = New System.Windows.Forms.TextBox
        Me.txtdays = New System.Windows.Forms.TextBox
        Me.txtplacename = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.lblbid = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btnreceipt = New System.Windows.Forms.Button
        Me.txtremainingamount = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.txttotalamount = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.txtcancellationcharges = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.btnticketcancellation = New System.Windows.Forms.Button
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.btnsearch = New System.Windows.Forms.Button
        Me.Label27 = New System.Windows.Forms.Label
        Me.lblcancellationdate = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtmobno
        '
        Me.txtmobno.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmobno.Location = New System.Drawing.Point(388, 135)
        Me.txtmobno.MaxLength = 10
        Me.txtmobno.Name = "txtmobno"
        Me.txtmobno.Size = New System.Drawing.Size(234, 31)
        Me.txtmobno.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(523, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(337, 42)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Cancellation Form"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(63, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(265, 24)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Enter Register Mobile Number"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblcancellationid)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.txtemailid)
        Me.GroupBox1.Controls.Add(Me.txtadharcardno)
        Me.GroupBox1.Controls.Add(Me.txtaddress)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.lblcid)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtname)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(65, 194)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(777, 157)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customer Details"
        '
        'lblcancellationid
        '
        Me.lblcancellationid.AutoSize = True
        Me.lblcancellationid.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcancellationid.Location = New System.Drawing.Point(557, 32)
        Me.lblcancellationid.Name = "lblcancellationid"
        Me.lblcancellationid.Size = New System.Drawing.Size(51, 18)
        Me.lblcancellationid.TabIndex = 11
        Me.lblcancellationid.Text = "Label5"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(423, 32)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(122, 18)
        Me.Label23.TabIndex = 10
        Me.Label23.Text = "Cancellation ID"
        '
        'txtemailid
        '
        Me.txtemailid.Location = New System.Drawing.Point(560, 110)
        Me.txtemailid.Name = "txtemailid"
        Me.txtemailid.ReadOnly = True
        Me.txtemailid.Size = New System.Drawing.Size(195, 24)
        Me.txtemailid.TabIndex = 9
        '
        'txtadharcardno
        '
        Me.txtadharcardno.Location = New System.Drawing.Point(560, 71)
        Me.txtadharcardno.Name = "txtadharcardno"
        Me.txtadharcardno.ReadOnly = True
        Me.txtadharcardno.Size = New System.Drawing.Size(195, 24)
        Me.txtadharcardno.TabIndex = 8
        '
        'txtaddress
        '
        Me.txtaddress.Location = New System.Drawing.Point(185, 113)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.ReadOnly = True
        Me.txtaddress.Size = New System.Drawing.Size(195, 24)
        Me.txtaddress.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(426, 112)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 18)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Email-ID"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(426, 73)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(119, 18)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Adhar Card No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(54, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 18)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Address"
        '
        'lblcid
        '
        Me.lblcid.AutoSize = True
        Me.lblcid.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcid.Location = New System.Drawing.Point(182, 32)
        Me.lblcid.Name = "lblcid"
        Me.lblcid.Size = New System.Drawing.Size(51, 18)
        Me.lblcid.TabIndex = 3
        Me.lblcid.Text = "Label5"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(54, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 18)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Customer ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(54, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 18)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Name"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(185, 66)
        Me.txtname.Name = "txtname"
        Me.txtname.ReadOnly = True
        Me.txtname.Size = New System.Drawing.Size(195, 24)
        Me.txtname.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txttotal)
        Me.GroupBox2.Controls.Add(Me.txtnoofold)
        Me.GroupBox2.Controls.Add(Me.txtnoofadult)
        Me.GroupBox2.Controls.Add(Me.txtnoofchild)
        Me.GroupBox2.Controls.Add(Me.txttodate)
        Me.GroupBox2.Controls.Add(Me.txtfromdate)
        Me.GroupBox2.Controls.Add(Me.txttravellingmode)
        Me.GroupBox2.Controls.Add(Me.txtfood)
        Me.GroupBox2.Controls.Add(Me.txthoteltype)
        Me.GroupBox2.Controls.Add(Me.txtdays)
        Me.GroupBox2.Controls.Add(Me.txtplacename)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.lblbid)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(67, 369)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(774, 314)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Booking Details"
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(531, 276)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.ReadOnly = True
        Me.txttotal.Size = New System.Drawing.Size(195, 24)
        Me.txttotal.TabIndex = 31
        '
        'txtnoofold
        '
        Me.txtnoofold.Location = New System.Drawing.Point(531, 231)
        Me.txtnoofold.Name = "txtnoofold"
        Me.txtnoofold.ReadOnly = True
        Me.txtnoofold.Size = New System.Drawing.Size(195, 24)
        Me.txtnoofold.TabIndex = 30
        '
        'txtnoofadult
        '
        Me.txtnoofadult.Location = New System.Drawing.Point(531, 184)
        Me.txtnoofadult.Name = "txtnoofadult"
        Me.txtnoofadult.ReadOnly = True
        Me.txtnoofadult.Size = New System.Drawing.Size(195, 24)
        Me.txtnoofadult.TabIndex = 29
        '
        'txtnoofchild
        '
        Me.txtnoofchild.Location = New System.Drawing.Point(531, 137)
        Me.txtnoofchild.Name = "txtnoofchild"
        Me.txtnoofchild.ReadOnly = True
        Me.txtnoofchild.Size = New System.Drawing.Size(195, 24)
        Me.txtnoofchild.TabIndex = 28
        '
        'txttodate
        '
        Me.txttodate.Location = New System.Drawing.Point(531, 95)
        Me.txttodate.Name = "txttodate"
        Me.txttodate.ReadOnly = True
        Me.txttodate.Size = New System.Drawing.Size(195, 24)
        Me.txttodate.TabIndex = 27
        '
        'txtfromdate
        '
        Me.txtfromdate.Location = New System.Drawing.Point(531, 45)
        Me.txtfromdate.Name = "txtfromdate"
        Me.txtfromdate.ReadOnly = True
        Me.txtfromdate.Size = New System.Drawing.Size(195, 24)
        Me.txtfromdate.TabIndex = 26
        '
        'txttravellingmode
        '
        Me.txttravellingmode.Location = New System.Drawing.Point(183, 279)
        Me.txttravellingmode.Name = "txttravellingmode"
        Me.txttravellingmode.ReadOnly = True
        Me.txttravellingmode.Size = New System.Drawing.Size(195, 24)
        Me.txttravellingmode.TabIndex = 25
        '
        'txtfood
        '
        Me.txtfood.Location = New System.Drawing.Point(183, 234)
        Me.txtfood.Name = "txtfood"
        Me.txtfood.ReadOnly = True
        Me.txtfood.Size = New System.Drawing.Size(195, 24)
        Me.txtfood.TabIndex = 24
        '
        'txthoteltype
        '
        Me.txthoteltype.Location = New System.Drawing.Point(183, 187)
        Me.txthoteltype.Name = "txthoteltype"
        Me.txthoteltype.ReadOnly = True
        Me.txthoteltype.Size = New System.Drawing.Size(195, 24)
        Me.txthoteltype.TabIndex = 23
        '
        'txtdays
        '
        Me.txtdays.Location = New System.Drawing.Point(183, 140)
        Me.txtdays.Name = "txtdays"
        Me.txtdays.ReadOnly = True
        Me.txtdays.Size = New System.Drawing.Size(195, 24)
        Me.txtdays.TabIndex = 22
        '
        'txtplacename
        '
        Me.txtplacename.Location = New System.Drawing.Point(183, 89)
        Me.txtplacename.Name = "txtplacename"
        Me.txtplacename.ReadOnly = True
        Me.txtplacename.Size = New System.Drawing.Size(195, 24)
        Me.txtplacename.TabIndex = 10
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(409, 279)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(46, 18)
        Me.Label19.TabIndex = 21
        Me.Label19.Text = "Total"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(409, 234)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(81, 18)
        Me.Label18.TabIndex = 20
        Me.Label18.Text = "No of Old"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(409, 187)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(92, 18)
        Me.Label17.TabIndex = 19
        Me.Label17.Text = "No of Adult"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(408, 140)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(93, 18)
        Me.Label16.TabIndex = 18
        Me.Label16.Text = "No of Child"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(408, 95)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(68, 18)
        Me.Label15.TabIndex = 17
        Me.Label15.Text = "To Date"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(408, 45)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(88, 18)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "From Date"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(40, 279)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(127, 18)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "Travelling Mode"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(42, 234)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 18)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Food"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(42, 187)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(89, 18)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "Hotel Type"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(42, 140)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 18)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "Days"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(42, 95)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(99, 18)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Place Name"
        '
        'lblbid
        '
        Me.lblbid.AutoSize = True
        Me.lblbid.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbid.Location = New System.Drawing.Point(180, 45)
        Me.lblbid.Name = "lblbid"
        Me.lblbid.Size = New System.Drawing.Size(51, 18)
        Me.lblbid.TabIndex = 10
        Me.lblbid.Text = "Label5"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(42, 45)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(91, 18)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Booking ID"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnreceipt)
        Me.GroupBox3.Controls.Add(Me.txtremainingamount)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.txttotalamount)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.txtcancellationcharges)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.btnticketcancellation)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(864, 194)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(402, 294)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Ticket Cancellation"
        '
        'btnreceipt
        '
        Me.btnreceipt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreceipt.Location = New System.Drawing.Point(263, 220)
        Me.btnreceipt.Name = "btnreceipt"
        Me.btnreceipt.Size = New System.Drawing.Size(130, 43)
        Me.btnreceipt.TabIndex = 15
        Me.btnreceipt.Text = "Receipt"
        Me.btnreceipt.UseVisualStyleBackColor = True
        '
        'txtremainingamount
        '
        Me.txtremainingamount.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtremainingamount.Location = New System.Drawing.Point(225, 157)
        Me.txtremainingamount.Name = "txtremainingamount"
        Me.txtremainingamount.ReadOnly = True
        Me.txtremainingamount.Size = New System.Drawing.Size(161, 24)
        Me.txtremainingamount.TabIndex = 14
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(23, 157)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(161, 20)
        Me.Label22.TabIndex = 13
        Me.Label22.Text = "Remaining Amount"
        '
        'txttotalamount
        '
        Me.txttotalamount.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttotalamount.Location = New System.Drawing.Point(225, 51)
        Me.txttotalamount.Name = "txttotalamount"
        Me.txttotalamount.ReadOnly = True
        Me.txttotalamount.Size = New System.Drawing.Size(161, 24)
        Me.txttotalamount.TabIndex = 12
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(23, 51)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(116, 20)
        Me.Label21.TabIndex = 11
        Me.Label21.Text = "Total Amount"
        '
        'txtcancellationcharges
        '
        Me.txtcancellationcharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcancellationcharges.Location = New System.Drawing.Point(225, 100)
        Me.txtcancellationcharges.Name = "txtcancellationcharges"
        Me.txtcancellationcharges.ReadOnly = True
        Me.txtcancellationcharges.Size = New System.Drawing.Size(161, 24)
        Me.txtcancellationcharges.TabIndex = 10
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(23, 104)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(180, 20)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Cancellation Charges"
        '
        'btnticketcancellation
        '
        Me.btnticketcancellation.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnticketcancellation.Location = New System.Drawing.Point(27, 220)
        Me.btnticketcancellation.Name = "btnticketcancellation"
        Me.btnticketcancellation.Size = New System.Drawing.Size(225, 43)
        Me.btnticketcancellation.TabIndex = 0
        Me.btnticketcancellation.Text = "Ticket Cancellation"
        Me.btnticketcancellation.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label26)
        Me.GroupBox4.Controls.Add(Me.Label25)
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(867, 501)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(431, 210)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "NOTE"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(6, 124)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(384, 20)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Ticket Cancellation Amount for Old = 500 RS. Per Old"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(6, 79)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(419, 20)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Ticket Cancellation Amount for Adult = 1000 RS. Per Adult"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(6, 34)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(406, 20)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Ticket Cancellation Amount for Child = 700 RS. Per Child"
        '
        'btnsearch
        '
        Me.btnsearch.BackgroundImage = Global.Tours_and_Travels_Management_System.My.Resources.Resources.search2
        Me.btnsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnsearch.Location = New System.Drawing.Point(654, 136)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(56, 34)
        Me.btnsearch.TabIndex = 1
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(861, 135)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(141, 18)
        Me.Label27.TabIndex = 12
        Me.Label27.Text = "Cancellation Date"
        '
        'lblcancellationdate
        '
        Me.lblcancellationdate.AutoSize = True
        Me.lblcancellationdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcancellationdate.Location = New System.Drawing.Point(1065, 135)
        Me.lblcancellationdate.Name = "lblcancellationdate"
        Me.lblcancellationdate.Size = New System.Drawing.Size(51, 18)
        Me.lblcancellationdate.TabIndex = 12
        Me.lblcancellationdate.Text = "Label5"
        '
        'frmcancellation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.lblcancellationdate)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.txtmobno)
        Me.Name = "frmcancellation"
        Me.Text = "frmcancellation"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtmobno As System.Windows.Forms.TextBox
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtemailid As System.Windows.Forms.TextBox
    Friend WithEvents txtadharcardno As System.Windows.Forms.TextBox
    Friend WithEvents txtaddress As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblcid As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblbid As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txttotal As System.Windows.Forms.TextBox
    Friend WithEvents txtnoofold As System.Windows.Forms.TextBox
    Friend WithEvents txtnoofadult As System.Windows.Forms.TextBox
    Friend WithEvents txtnoofchild As System.Windows.Forms.TextBox
    Friend WithEvents txttodate As System.Windows.Forms.TextBox
    Friend WithEvents txtfromdate As System.Windows.Forms.TextBox
    Friend WithEvents txttravellingmode As System.Windows.Forms.TextBox
    Friend WithEvents txtfood As System.Windows.Forms.TextBox
    Friend WithEvents txthoteltype As System.Windows.Forms.TextBox
    Friend WithEvents txtdays As System.Windows.Forms.TextBox
    Friend WithEvents txtplacename As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtremainingamount As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txttotalamount As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtcancellationcharges As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents btnticketcancellation As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents lblcancellationid As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents btnreceipt As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents lblcancellationdate As System.Windows.Forms.Label
End Class
